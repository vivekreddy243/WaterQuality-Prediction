package com.example.waterqualityapp;

public class Waterquality {
    public String ph;
    public String Hardness;
    public String Solids;
    public String Chloramines;
    public String Sulphate;
    public String Conductivity;
    public String Trihalomethanes;
    public String Turbidity;
    public String Organiccarbon;
}
