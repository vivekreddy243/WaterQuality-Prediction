package com.example.waterqualityapp;

import  androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public abstract class MainActivity<RequestQueue> extends AppCompatActivity {
    Waterquality waterquality;
    TextView textWQL;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        waterquality = new Waterquality();
        textWQL= findViewById(R.id.textWQL);
    }

    public void PredictWQL(View view) {

        EditText textph = findViewById(R.id.editTextPH);
        waterquality.ph = textph.getText().toString();

        EditText textHardness = findViewById(R.id.editTextHardness);
        waterquality.Hardness = textHardness.getText().toString();

        EditText textSolids = findViewById(R.id.editTextSolids);
        waterquality.Solids = textSolids.getText().toString();

        EditText textChloramines = findViewById(R.id.editTextChloramines);
        waterquality.Chloramines = textChloramines.getText().toString();

        EditText textSulphate = findViewById(R.id.editTextSulphate);
        waterquality.Sulphate = textSulphate.getText().toString();

        EditText textConductivity = findViewById(R.id.editTextConductivity);
        waterquality.Conductivity = textConductivity.getText().toString();

        EditText textOrganiccarbon = findViewById(R.id.editTextOrganiccarbon);
        waterquality.Organiccarbon = textOrganiccarbon.getText().toString();

        EditText textTrihalomethanes = findViewById(R.id.editTextTrihalomethanes);
        waterquality.Trihalomethanes = textTrihalomethanes.getText().toString();

        EditText textTurbidity = findViewById(R.id.editTextTurbidity);
        waterquality.Turbidity = textTurbidity.getText().toString();





//        textGLD.setText(GetData());
        textWQL.setText(GetUrl());

//        textGLD.setText(GetUrl());

        GetWQL(GetUrl());
        textWQL.setText("wait..");
    }

    private String GetData() {

        String data="";
        data += "ph : " + waterquality.ph + "\r\n";
        data += "Hardness: " + waterquality.Hardness + "\r\n";
        data += "Solids: " + waterquality.Solids + "\r\n";
        data += "Chloramines: " + waterquality.Chloramines + "\r\n";
        data += ".Sulphate: " + waterquality.Sulphate + "\r\n";
        data += "Conductivity: " + waterquality.Conductivity + "\r\n";
        data += "Organiccarbon: " + waterquality.Organiccarbon + "\r\n";
        data += "Trihalomethanes: " +waterquality.Trihalomethanes + "\r\n";
        data += "Turbidity: " + waterquality.Turbidity ;

        return data;
    }

    private String GetUrl(){
        String url = "https://api.datalabs.info/api/v1/PredictWaterquality?";
        url += "ph : " + waterquality.ph + "\r\n";
        url += "Hardness: " + waterquality.Hardness + "\r\n";
        url += "Solids: " + waterquality.Solids + "\r\n";
        url += "Chloramines: " + waterquality.Chloramines + "\r\n";
        url += ".Sulphate: " + waterquality.Sulphate + "\r\n";
        url += "Conductivity: " + waterquality.Conductivity + "\r\n";
        url += "Organiccarbon: " + waterquality.Organiccarbon + "\r\n";
        url += "Trihalomethanes: " +waterquality.Trihalomethanes + "\r\n";
        url += "Turbidity: " + waterquality.Turbidity ;


        return url;
    }

    private void GetWQL(String url) {

        // creating a new variable for our request queue
        com.android.volley.RequestQueue queue = Volley.newRequestQueue(MainActivity.this);

        // make json array request and then extracting data from each json object.
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject responseObj = response.getJSONObject(0);

                    String returnValue = responseObj.getString("Potability ");
                    textWQL.setText("Potability: " + returnValue);

                    Toast.makeText(MainActivity.this, returnValue, Toast.LENGTH_SHORT).show();

                } catch (JSONException e) {
                    throw new RuntimeException(e);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity.this, "Fail to get the data..", Toast.LENGTH_SHORT).show();
            }
        });
        queue.add(jsonArrayRequest);
    }


}

